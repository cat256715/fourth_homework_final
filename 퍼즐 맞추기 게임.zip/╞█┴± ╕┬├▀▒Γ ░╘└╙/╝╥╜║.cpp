#include <bangtal>
using namespace bangtal;
#include <time.h>
#include <stdlib.h>

SceneID scene;
ObjectID game_board[12], init_board[12];
ObjectID start;
ObjectID restart;

const char* board_image[12] = {
	"Images/1.jpg",
	"Images/2.jpg",
	"Images/3.jpg",
	"Images/4.jpg",
	"Images/5.jpg",
	"Images/6.jpg",
	"Images/7.jpg",
	"Images/8.jpg",
	"Images/9.jpg",
	"Images/10.jpg",
	"Images/11.jpg",
	"Images/12.jpg"
};

const int board_x[12] = { 0, 0, 0, 320, 320, 320, 640, 640, 640, 960, 960, 960 };
const int board_y[12] = { 480, 240, 0, 480, 240, 0, 480, 240, 0, 480, 240, 0 };

int blank;

TimerID timer;
int mixCount;

int board_index(ObjectID object) {
	for (int i = 0; i < 12; i++) {
		if (game_board[i] == object) return i;
	}
	return -1;
}

void board_move(int index) {
	ObjectID t = game_board[blank];
	game_board[blank] = game_board[index];
	game_board[index] = t;

	locateObject(game_board[blank], scene, board_x[blank], board_y[blank]);
	locateObject(game_board[index], scene, board_x[index], board_y[index]);

	blank = index;
}

bool movable(int index) {
	if (blank < 0 or blank > 11) return false;
	if (blank % 3 != 0 and blank - 1 == index) return true;
	if (blank % 3 != 2 and blank + 1 == index) return true;
	if (blank / 3 != 0 and blank - 3 == index) return true;
	if (blank / 3 != 3 and blank + 3 == index) return true;

	return false;
}

void board_mix() {
	int index;

	do {
		switch (rand() % 4) {
		case 0: index = blank - 1; break;
		case 1: index = blank + 1; break;
		case 2: index = blank - 3; break;
		case 3: index = blank + 3; break;
		}
	} while (!movable(index));
	board_move(index);

	if (movable(index))
		board_move(index);
}

bool completed() {
	for (int i = 0; i < 12; i++) {
		if (game_board[i] != init_board[i]) return false;
	}
	return true;
}

void mouseCallback(ObjectID object, int x, int y, MouseAction action) {
	if (object == start) {
		mixCount = 10;

		setTimer(timer, 1.f);
		startTimer(timer);
		hideObject(start);
	}
	else if (object == restart) {
		mixCount = 10;

		setTimer(timer, 1.f);
		startTimer(timer);
		hideObject(restart);
	}
	else {
		int index = board_index(object);
		if (movable(index)) {
			board_move(index);

			if (completed()) {
				showMessage("Completed!!");
				showObject(restart);
			}
		}
	}
}

void timerCallback(TimerID timer) {
	mixCount--;

	if (mixCount > 0) {
		board_mix();

		setTimer(timer, 1.f);
		startTimer(timer);
	}
}

int main() {
	setMouseCallback(mouseCallback);
	setTimerCallback(timerCallback);

	scene = createScene("Images\\���.jpg");

	for (int i = 0; i < 12; i++) {
		game_board[i] = createObject(board_image[i]);
		init_board[i] = game_board[i];

		locateObject(game_board[i], scene, board_x[i], board_y[i]);
		showObject(game_board[i]);
	}

	blank = 11;
	hideObject(game_board[blank]);

	start = createObject("Images\\start.jpg");
	locateObject(start, scene, 590, 100);
	showObject(start);

	restart = createObject("Images\\restart.jpg");
	locateObject(restart, scene, 590, 100);


	timer = createTimer(1.f);

	startGame(scene);

	return 0;
}